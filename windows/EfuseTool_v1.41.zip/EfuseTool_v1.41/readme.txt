v1.4 revision(20191209):
1.fix get wrong key hash when you select 3288 and 3399 firmware

