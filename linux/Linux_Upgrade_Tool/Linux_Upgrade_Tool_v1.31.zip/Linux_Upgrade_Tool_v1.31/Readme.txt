v1.28 revision:
1.support to download sparse image and  erase verity info
2.support to erase emmc using erase_lba

v1.3 revision:
1.support gpt download
2.add pl to read partition info from device

v1.31 revision:
1.UL decide to if reset or not after upgrade loader
2.add "rb_check_off"flag in the config.ini.close readback check when set rb_check_off=true
